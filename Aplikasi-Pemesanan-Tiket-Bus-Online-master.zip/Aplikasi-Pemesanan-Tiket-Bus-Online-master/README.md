#Aplikasi Pemesanan Tiket Bus Online (PHP, MySQL, CMS Lokomedia)
Login pengguna:

Administrator:

    Username: admin
    Password: admin

Customer/member:

    Username: aaa@gmail.com
    Password: aaa

Semoga bermanfaat.

malescoding.com