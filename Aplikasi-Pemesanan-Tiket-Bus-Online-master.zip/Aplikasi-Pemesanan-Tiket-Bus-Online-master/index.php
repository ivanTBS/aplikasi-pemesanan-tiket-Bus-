<?php
  header('location:home'); 
?>
